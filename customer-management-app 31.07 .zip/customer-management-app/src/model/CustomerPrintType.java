package model;

public enum CustomerPrintType {
    DEFAULT,
    IDENTIFIED,
    UNIDENTIFIED
}
